<?php
    include('../Admin/sistema.controller.php');
    $sistema = new Sistema();
    $action = (isset($_GET['action']))?$_GET['action']:'read';
    include('views/header.php');
    $mensaje='';
    switch($action)
    {  
        case 'logout':
            unset($_SESSION);
            session_destroy();
            $mensaje= 'Ha salido del sistema.';
            include('views/login.php');

            break;
        case 'validate':
            if(isset($_POST['enviar'])){
                $correo = $_POST['correo'];
                $contrasena= $_POST['contrasena'];
                if($sistema->ValidateEmail($correo)){
                   
                    if($sistema ->ValidateUser($correo,$contrasena)){
                        $roles= $sistema-> GetRoles($correo);
                        $permisos= $sistema-> GetPermisos($correo);
                        $_SESSION['validado']=true;
                        $_SESSION['roles']=$roles;
                        $_SESSION['permisos']= $permisos;
                        $_SESSION['correo']= $correo;
                        header('Location: ../Admin/index.php');
                    }else{
                        echo 'usuario o contraseña incorrecto';
                    }
                }else{
                    echo 'no puedo continuar';
                }
            }
            break;
        default:
            include('views/login.php');
            break;
    }
    include('views/footer.php');
?>