<?php
    include('doctor.controller.php');
    include('usuario.controller.php');
    $sistema = new Sistema;
    $doctores = new Doctor;
    $usuarios= new Usuario;
    $action = (isset($_GET['action']))?$_GET['action']:'read';
    $tipos=$tipo_producto->read();

    include('views/header.php');
    switch($action)
    {
        case 'create':
            include('views/doctor/form.php');
            break;

        case 'save':
            $doctor=$_POST['doctor'];
            $resultado = $doctores->create($doctor['apaterno'], $doctor['amaterno'],$doctor['nombre'],$doctor['especialidad'],$doctor['id_usuario']);
            $datos = $doctores->read();
            include('views/doctor/index.php');
            break;
        case 'delete':
            $id_doctor = $_GET['id_doctor'];
            $resultado = $doctores->delete($id_doctor);
            $datos = $doctores->read();
            include('views/doctor/index.php');
            break;
        case 'show':
            $id_doctor = $_GET['id_doctor'];
            $datos = $doctores->readOne($id_doctor);
            include('views/doctor/form.php');
            break;
        case 'update': 
            $doctor = $_POST['doctor'];
            $resultado = $doctores->update($doctor['id_doctor'],$doctor['apaterno'],$doctor['amaterno'],$doctor['nombre'],$doctor['especialidad'],$doctor['id_usuario']);
            $datos = $doctores->read();
            include('views/doctor/index.php');
            break;
        default:
            $datos = $doctores->read();
            include('views/doctor/index.php');
            break;
    }
    include('views/footer.php');
?>