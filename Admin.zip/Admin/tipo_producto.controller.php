<?php 
    require_once('sistema.controller.php');
    class Tipo_producto extends Sistema
    {
      var $id_tipo_producto;
      var $tipo_producto;  
    
    function getId_tipo_producto()
    {
        return $this->id_tipo_producto;
    }
    function setId_tipo_producto($id_tipo_producto){
        $this-> id_tipo_producto = $id_tipo_producto;
    }
    function getTipo_producto()
    {
        return $this->tipo_producto;
    }
    function setTipo_producto($tipo_producto)
    {
        $this-> tipo_producto = $tipo_producto;
    }

    function create($tipo_producto)
    {
        $dbh = $this->Connect();
        $sentencia = "INSERT INTO tipo_producto(tipo_producto) VALUES (:tipo_producto)";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':tipo_producto',$tipo_producto, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }

    function read(){
        $dbh = $this->Connect();
        $sentencia = ("SELECT * FROM tipo_producto");
        $stmt = $dbh->prepare($sentencia);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return $rows;

    }

    function readOne($id_tipo_producto){
        $dbh = $this->Connect();
        $this->setId_tipo_producto($id_tipo_producto);
        $sentencia = "SELECT * FROM tipo_producto where id_tipo_producto= :id_tipo_producto";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_tipo_producto',$id_tipo_producto, PDO::PARAM_STR);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return $rows;
    }

    function update($id_tipo_producto, $tipo_producto){
        $dbh = $this->Connect();
        $sentencia="UPDATE tipo_producto 
                        SET tipo_producto=:tipo_producto 
                        where id_tipo_producto=:id_tipo_producto";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_tipo_producto',$id_tipo_producto, PDO::PARAM_STR);
        $stmt->bindParam(':tipo_producto',$tipo_producto, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }

    function delete($id_tipo_producto){
        $dbh=$this->Connect();
        $sentencia = "delete FROM tipo_producto where id_tipo_producto=:id_tipo_producto";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_tipo_producto',$id_tipo_producto, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }
}
$producto = new Tipo_producto();
$resultado;
//$resultado = $producto->create('Producto5');
//echo '<pre>';
//$resultado=$producto->read();
//print_r($resultado);
//$resultado=$producto->readOne(1);
//print_r($resultado);
//$resultado=$producto->update(1,'Producto fyfy');
//print_r($resultado);
//$resultado=$producto->delete(2);
//print_r($resultado);
//$resultado=$producto->delete(1);
//print_r($resultado);
//$resultado=$producto->read();
//print_r($resultado);


?>
