<?php 
    require_once('sistema.controller.php');
    class Rol extends Sistema
    {
      var $id_rol;
      var $rol;  
    
    function getId_rol()
    {
        return $this->id_rol;
    }
    function setId_rol($id_rol){
        $this-> id_rol = $id_rol;
    }
    function getRol()
    {
        return $this->rol;
    }
    function setRol($rol)
    {
        $this-> rol = $rol;
    }

    function create($rol)
    {
        $dbh = $this->Connect();
        $sentencia = "INSERT INTO rol(rol) VALUES (:rol)";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':rol',$rol, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }

    function read(){
        $dbh = $this->Connect();
        $sentencia = ("SELECT * FROM rol");
        $stmt = $dbh->prepare($sentencia);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return $rows;

    }

    function readOne($id_rol){
        $dbh = $this->Connect();
        $this->setId_rol($id_rol);
        $sentencia = "SELECT * FROM rol where id_rol= :id_rol";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_rol',$id_rol, PDO::PARAM_STR);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return $rows;
    }

    function update($id_rol, $rol){
        $dbh = $this->Connect();
        $sentencia="UPDATE rol 
                        SET rol=:rol 
                        where id_rol=:id_rol";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_rol',$id_rol, PDO::PARAM_STR);
        $stmt->bindParam(':rol',$rol, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }

    function delete($id_rol){
        $dbh=$this->Connect();
        $sentencia = "delete FROM rol where id_rol=:id_rol";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_rol',$id_rol, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }
}


?>