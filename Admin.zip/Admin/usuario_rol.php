<?php
    include('usuario_rol.controller.php');
    $usuarios_rol= new Usuario_rol;
    $action = (isset($_GET['action']))?$_GET['action']:'read';
    include('views/header.php');
    switch($action)
    {
        case 'create':
            include('views/usuario_rol/form.php');
            break;

        case 'save':
            $id_rol=$_POST['usuario_rol'];
            $resultado = $id_rol->create($id_rol['id_usuario']);
            $datos = $ids_rol->read();
            include('views/usuario_rol/index.php');
            break;
        case 'delete':
            $id_usuario=$_GET['id_usuario'];
            $resultado = $usuarios_rol->delete($id_usuario);
            $datos = $usuarios_rol->read();
            include('views/usuario_rol/index.php');
            break;
        case 'show':
            $id_usuario = $_GET['id_usuario'];
            $datos = $usuarios_rol->readOne($id_usuario);
            include('views/usuario_rol/form.php');
            break;
        case 'update': 
            $id_rol = $_POST['usuario_rol'];
            $resultado = $usuarios_rol->update($id_rol['id_rol'],$id_rol['id_usuario']);
            $datos = $usuarios_rol->read();
            include('views/usuario_rol/index.php');
            break;
        default:
            $datos = $usuarios_rol->read();
            include('views/usuario_rol/index.php');
            break;
    }
    include('views/footer.php');
?>