<?php
    require('sistema.controller.php');

    class Doctor extends Sistema{
        var $id_doctor;
        var $apaterno;
        var $amaterno;
        var $nombre;
        var $especialidad;
        var $id_usuario;

        function setId_doctor($id){
            $this-> id_doctor = $id;
 
        }
        function getId_doctor(){
         return $this->id_doctor;
        }
        function setApaterno($apaterno){
         $this-> apaterno = $apaterno;
        }
        function getApaterno(){
         return $this->apaterno;
        }
        function setAmaterno($amaterno){
         $this-> amaterno = $amaterno;
        }
        function getAmaterno(){
            return $this->amaterno;
        }
        function setNombre($nombre){
            $this-> nombre = $nombre;
           }
        function getNombre(){
            return $this->nombre;
        }
        function setEspecialidad($especialidad){
            $this-> especialidad = $especialidad;
           }
        function getEspecialidad(){
            return $this->especialidad;
        }
        function setId_usuario($id_usuario){
            $this-> id_usuario = $id_usuario;
           }
           function getId_usuario(){
               return $this->id_usuario;
           }

        function create($apaterno,$amaterno,$nombre,$especialidad,$id_usuario){
            $dbh = $this->Connect();
            $sentencia = "INSERT INTO doctor(apaterno,amaterno,nombre,especialidad,id_usuario) VALUES (:apaterno,:amaterno,:nombre,:especialidad,:id_usuario)";
            $stmt = $dbh->prepare($sentencia);
            $stmt->bindParam(':apaterno',$apaterno, PDO::PARAM_STR);
            $stmt->bindParam(':amaterno',$apaterno, PDO::PARAM_STR);
            $stmt->bindParam(':apaterno',$apaterno, PDO::PARAM_STR);
            $stmt->bindParam(':nombre',$apaterno, PDO::PARAM_STR);
            $stmt->bindParam(':especialidad',$especialidad, PDO::PARAM_STR);
            $stmt->bindParam(':id_usuario',$id_usuario, PDO::PARAM_STR);
            $resultado = $stmt->execute();
            return $resultado;
        }
        function read(){
            $dbh = $this->Connect();
            $sentencia = ("SELECT * FROM doctor");
            $stmt = $dbh->prepare($sentencia);
            $stmt->execute();
            $rows = $stmt->fetchAll();
            return $rows;

        }
        function readOne($id_producto){
        $dbh = $this->Connect();
        $sentencia = "SELECT * FROM doctor where id_doctor= :id_doctor";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_doctor',$id_doctor, PDO::PARAM_STR);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return $rows;
        }

        function update($id_doctor, $apaterno, $amaterno,$nombre,$especialidad, $id_usuario){
            $dbh = $this->Connect();
            $sentencia="UPDATE doctor 
                            SET apaterno=:apaterno,
                                amaterno=:amaterno,
                                nombre=:nombre,
                                especialidad=:especialidad,
                                id_usuario=:id_usuario  
                            where id_doctor=:id_doctor";
            $stmt = $dbh->prepare($sentencia); 
            $stmt->bindParam(':id_doctor',$id_doctor, PDO::PARAM_STR);
            $stmt->bindParam(':apaterno',$apaterno, PDO::PARAM_STR);
            $stmt->bindParam(':amaterno',$amaterno, PDO::PARAM_STR);
            $stmt->bindParam(':nombre',$nombre, PDO::PARAM_STR);
            $stmt->bindParam(':espacialidad',$especialidad, PDO::PARAM_STR);
            $stmt->bindParam(':id_usuario',$id_usuario, PDO::PARAM_INT);
            $resultado = $stmt->execute();
            return $resultado;
            
        }

        function delete($id_producto){
            $dbh=$this->Connect();
            $sentencia = "delete FROM doctor where id_doctor=:id_doctor";
            $stmt = $dbh->prepare($sentencia);
            $stmt->bindParam(':id_doctor',$id_doctor, PDO::PARAM_STR);
            $resultado = $stmt->execute();
            return $resultado;
        }

        
    }
?>