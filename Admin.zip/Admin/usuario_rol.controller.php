<?php 
    require_once('sistema.controller.php');
    class Usuario_rol extends Sistema
    {
      var $id_usuario;
      var $id_rol;  
    
    function getId_usuario()
    {
        return $this->id_usuario;
    }
    function setId_usuario($id_usuario){
        $this-> id_usuario = $id_usuario;
    }
    function getId_rol()
    {
        return $this->id_rol;
    }
    function setId_rol($id_rol)
    {
        $this-> id_rol = $id_rol;
    }

    function create($id_rol)
    {
        $dbh = $this->Connect();
        $sentencia = "INSERT INTO usuario_rol(id_rol) VALUES (:id_rol)";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_rol',$id_rol, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }

    function read(){
        $dbh = $this->Connect();
        $sentencia = ("SELECT * FROM usuario_rol");
        $stmt = $dbh->prepare($sentencia);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return $rows;

    }

    function readOne($id_usuario){
        $dbh = $this->Connect();
        $this->setId_usuario($id_usuario);
        $sentencia = "SELECT * FROM usuario_rol where id_usuario= :id_usuario";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_usuario',$id_usuario, PDO::PARAM_STR);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return $rows;
    }

    function update($id_usuario, $id_rol){
        $dbh = $this->Connect();
        $sentencia="UPDATE usuario_rol 
                        SET id_usuario=:id_usuario,
                        id_rol=:id_rol 
                        where id_usuario=:id_usuario";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_usuario',$id_usuario, PDO::PARAM_STR);
        $stmt->bindParam(':id_rol',$id_rol, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }

    function delete($id_usuario){
        $dbh=$this->Connect();
        $sentencia = "delete FROM usuario_rol where id_usuario=:id_usuario";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_usuario',$id_usuario, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }
}
//$producto = new Tipo_producto();
//$resultado;
//$resultado = $producto->create('Producto5');
//echo '<pre>';
//$resultado=$producto->read();
//print_r($resultado);
//$resultado=$producto->readOne(1);
//print_r($resultado);
//$resultado=$producto->update(1,'Producto fyfy');
//print_r($resultado);
//$resultado=$producto->delete(2);
//print_r($resultado);
//$resultado=$producto->delete(1);
//print_r($resultado);
//$resultado=$producto->read();
//print_r($resultado);


?>
