<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Doctor
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">

            <li><a class="dropdown-item" href="pacientes.php">Pacientes</a></li>
            <li><a class="dropdown-item" href="pacientes.php?action=my">Mis pacientes</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="producto.php">Productos</a></li>
       
          </ul>
        </li>