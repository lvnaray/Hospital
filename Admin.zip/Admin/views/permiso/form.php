<form action="permiso.php?action=<?php echo(isset($datos))? 'update': 'save';?>" method="POST" enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleFormControlInput1">Permiso</label>
    <input type="text" name="permiso[permiso]" value="<?php echo (isset($datos[0]['permiso']))?$datos[0]['permiso']:'';?>" class="form-control" id="permiso" placeholder="permiso" >
  
  </div>

    
  </div>
  <div class="form-group">
  <input type="hidden" name="permiso[id_permiso]" value="<?php echo (isset($datos[0]['id_permiso']))?$datos[0]['id_permiso']:'';?>">
    <input type="submit" name="enviar" value="Guardar" class="btn btn-success" />
  </div>
  