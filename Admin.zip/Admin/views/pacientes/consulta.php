<div class="d-flex flex-column justify-content-center align-items-center">
  <div class="w-100 p-3 text-center" style="background-color: #eee;font-size: 17px;">
    <img src="<?php echo (isset($datos[0]['fotografia']))? 'archivos/'.$datos[0]['fotografia']: 'archivos/default.jpg';?>" widht="80" height="200" class="rounded-circle">
    <h3>Nombre: <?php echo $datos[0]['nombre'];?></h3>
    <h3>Apellido Paterno: <?php echo $datos[0]['apaterno'];?></h3>
    <h3>Apellido materno: <?php echo $datos[0]['amaterno'];?></h3>
    <h3>Edad: <?php echo $datos[0]['edad'];?></h3>

<h3>NUEVA CONSULTA</h3>
<form action="pacientes.php?action=consulta_nueva" method="POST">
  <div class="form-group">
    <label for="exampleInputEmail1">Padecimiento</label>
    <input  class="form-control" name="consulta[padecimiento]" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Tratamiento</label>
    <input class="form-control" name="consulta[tratamiento]" id="exampleInputPassword1">
  </div>
  <div>
  <input type="hidden" name="consulta[id_paciente]" value="<?php echo (isset($datos[0]['id_paciente']))?$datos[0]['id_paciente']:'';?>">
    <input type="submit" name="enviar" value="Guardar consulta" class="btn btn-success" />
  </div>
</form>
<BR>
</div>
<table class="table">
  <thead>
    <tr>
      <th scope="col">ID consulta</th>
      <th scope="col">FECHA</th>
      <th scope="col">PADECIMIENTO</th>
      <th scope="col">DOCTOR</th>
      <th scope="col">BOTONES</th>

    </tr>
  </thead>
  <tbody>
  <h1>CONSULTAS</h1>
  <?php foreach($consultas as $key => $consulta):?>
    <tr>
      <th scope="row"><?=$consulta['id_consulta'] ?></th><!--id-->
      <td><?=$consulta['fecha'] ?></td><!--nombre-->
      <td><?=$consulta['padecimiento'] ?></td><!--apaterno-->
      <td><?=$consulta['doctor'] ?></td><!--amaterno-->

      <td><a href="pacientes.php?action=receta&id_consulta=<?=$consulta['id_consulta']?>"
                                       class="btn btn-info">
                                        <i class="fas fa-print"></i> Imprimir receta</a></td><!--modificar-->

    </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>


