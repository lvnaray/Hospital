<form action="usuario.php?action=<?php echo(isset($datos))? 'update': 'save';?>" method="POST" enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleFormControlInput1">Usuario</label>
    <input type="text" name="usuario[correo]" value="<?php echo (isset($datos[0]['correo']))?$datos[0]['correo']:'';?>" class="form-control" id="correo" placeholder="correo" >
  
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">Contraseña</label>
    <input type="text" name="usuario[contrasena]" value="<?php echo (isset($datos[0]['contrasena']))?$datos[0]['contrasena']:'';?>" class="form-control" id="contrasena" placeholder="contrasena">
  
  </div>
  
    
  </div>
  <div class="form-group">
  <input type="hidden" name="usuario[id_usuario]" value="<?php echo (isset($datos[0]['id_usuario']))?$datos[0]['id_usuario']:'';?>">
    <input type="submit" name="enviar" value="Guardar" class="btn btn-success" />
  </div>