<form action="rol.php?action=<?php echo(isset($datos))? 'update': 'save';?>" method="POST" enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleFormControlInput1">ROL</label>
    <input type="text" name="rol[rol]" value="<?php echo (isset($datos[0]['rol']))?$datos[0]['rol']:'';?>" class="form-control" id="rol" placeholder="rol" >
  
  </div>

    
  </div>
  <div class="form-group">
  <input type="hidden" name="rol[id_rol]" value="<?php echo (isset($datos[0]['id_rol']))?$datos[0]['id_rol']:'';?>">
    <input type="submit" name="enviar" value="Guardar" class="btn btn-success" />
  </div>
  