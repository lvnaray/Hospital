<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Administrador
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tipo_producto.php">Tipos de producto</a></li>
            <li><a class="dropdown-item" href="usuario.php">Usuario</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="producto.php">Productos</a></li>
            <li><a class="dropdown-item" href="permiso.php">Permisos</a></li>
            <li><a class="dropdown-item" href="rol.php">Roles</a></li>
          </ul>
        </li>