<?php 
    define('PASSGMAIL','Lunettoo89');
?>