<?php 
    require_once('sistema.controller.php');
    class Permiso extends Sistema
    {
      var $id_permiso;
      var $permiso;  
    
    function getId_permiso()
    {
        return $this->id_permiso;
    }
    function setId_permiso($id_permiso){
        $this-> id_permiso = $id_permiso;
    }
    function getPermiso()
    {
        return $this->permiso;
    }
    function setPermiso($permiso)
    {
        $this-> permiso = $permiso;
    }

    function create($permiso)
    {
        $dbh = $this->Connect();
        $sentencia = "INSERT INTO permiso(permiso) VALUES (:permiso)";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':permiso',$permiso, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }

    function read(){
        $dbh = $this->Connect();
        $sentencia = ("SELECT * FROM permiso");
        $stmt = $dbh->prepare($sentencia);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return $rows;

    }

    function readOne($id_permiso){
        $dbh = $this->Connect();
        $this->setId_permiso($id_permiso);
        $sentencia = "SELECT * FROM permiso where id_permiso= :id_permiso";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_permiso',$id_permiso, PDO::PARAM_STR);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return $rows;
    }

    function update($id_permiso, $permiso){
        $dbh = $this->Connect();
        $sentencia="UPDATE permiso 
                        SET permiso=:permiso 
                        where id_permiso=:id_permiso";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_permiso',$id_permiso, PDO::PARAM_STR);
        $stmt->bindParam(':permiso',$permiso, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }

    function delete($id_permiso){
        $dbh=$this->Connect();
        $sentencia = "delete FROM permiso where id_permiso=:id_permiso";
        $stmt = $dbh->prepare($sentencia);
        $stmt->bindParam(':id_permiso',$id_permiso, PDO::PARAM_STR);
        $resultado = $stmt->execute();
        return $resultado;
    }
}

//$resultado = $producto->create('Producto5');
//echo '<pre>';
//$resultado=$producto->read();
//print_r($resultado);
//$resultado=$producto->readOne(1);
//print_r($resultado);
//$resultado=$producto->update(1,'Producto fyfy');
//print_r($resultado);
//$resultado=$producto->delete(2);
//print_r($resultado);
//$resultado=$producto->delete(1);
//print_r($resultado);
//$resultado=$producto->read();
//print_r($resultado);


?>